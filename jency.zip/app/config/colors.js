export default {
	primary_white: "#f5f5f5",
	primary_black: "#211522",
	secondary_cinnamon: "#cc7638",
	secondary_grey: "#808080",
	accent_green: "#7a9000",
	accent_red: "#ed4b60",
	opaque_black: "rgba(0,0,0,0.6)",
	pure_white: "#ffffff",
};
